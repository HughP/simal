The xhtml1 DTDs were obtained from the TAR archive provided at:
http://www.w3.org/TR/xhtml1/#dtds

The W3C license was obtained from:
http://www.w3.org/Consortium/Legal/2002/copyright-software-20021231

The SVG DTDs were obtained directly from their published System Identifiers.
