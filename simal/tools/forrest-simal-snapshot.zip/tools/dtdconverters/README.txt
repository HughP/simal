These files are from NekoDTD (http://www.apache.org/~andyc/neko/doc/dtd/), and
are used to convert the intermediate XML representation of a DTD to other
formats.
